import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const checkAuthenticationStatus = async () => {
      try {
        const response = await fetch('http://localhost:3001/session-info', {
          method: 'GET',
          credentials: 'include',
        });

        if (response.ok) {
          const userData = await response.json();
          setIsLoggedIn(!!userData.user);
        }
      } catch (error) {
        console.error('Error checking authentication status:', error);
      }
    };

    checkAuthenticationStatus();
  }, []);

  const handleLogout = async () => {
    try {
      const response = await fetch('http://localhost:3001/logout', {
        method: 'POST',
        credentials: 'include',
      });

      if (response.ok) {
        console.log('Logout successful');
        window.location.href = '/login';
      } else {
        console.error('Logout failed');
      }
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  return (
    <nav className="bg-gray-800 p-4">
      <div className="container mx-auto">
        <div className="flex items-center justify-between">
          <Link to="/" className="text-white">Home</Link>

          <div className="flex items-center space-x-4">
            {isLoggedIn ? (
              <>
                <Link to="/tasks" className="text-white">Tasks</Link>
                <Link to="/profile" className="text-white">Profile</Link>
                <button
                  onClick={handleLogout}
                  className="text-white rounded-full px-4 py-2 bg-gradient-to-r from-purple-900 via-blue-800 to-blue-800 transition duration-300 hover:from-purple-900 hover:via-purple-900 hover:to-blue-800"
                >
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="text-white">Login</Link>
                <Link to="/signup" className="text-white rounded-full px-4 py-2 bg-gradient-to-r from-purple-900 via-blue-800 to-blue-800 transition duration-300 hover:from-purple-900 hover:via-purple-900 hover:to-blue-800">Signup</Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
