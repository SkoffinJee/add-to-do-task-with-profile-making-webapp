import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch("http://localhost:3001/login", {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        const data = await response.json();
        console.log(data.message);

        // Redirect to the Home page
        navigate('/');
        window.location.reload();
      } else {
        // Login failed
        const errorData = await response.json();
        console.error(errorData.err);
        // Display error message to the user
        // You can update the state to show the error message in the UI
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <div className="bg-cover bg-center h-screen" style={{ backgroundImage: 'url("../media/loginbg.jpg")' }}>
      <div className="flex items-center justify-center h-screen">
        <div className="w-96 mx-auto p-6 bg-gray-700 shadow-md rounded-md">
          <h2 className="text-3xl font-semibold mb-6 text-center text-purple-600">Login</h2>
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label htmlFor="username" className="block text-sm font-medium text-gray-300">
                Username:
              </label>
              <input
                type="text"
                id="username"
                name="username"
                value={formData.username}
                onChange={handleChange}
                className="mt-1 p-2 border border-purple-800 w-full rounded-full bg-gray-800 text-white focus:outline-none focus:ring focus:border-purple-600"
              />
            </div>
            <div className="mb-6">
              <label htmlFor="password" className="block text-sm font-medium text-gray-300">
                Password:
              </label>
              <input
                type="password"
                id="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                className="mt-1 p-2 border border-purple-800 w-full rounded-full bg-gray-800 text-white focus:outline-none focus:ring focus:border-purple-600"
              />
            </div>
            <button
            type="submit"
            className="w-full bg-gradient-to-r from-purple-800 via-purple-800 to-blue-900 text-white p-2 rounded-full hover:from-purple-900 hover:via-purple-900 hover:to-blue-900 focus:outline-none focus:ring focus:border-purple-900"
          >
            Login
          </button>

          </form>
          <p className="mt-4 text-sm text-center text-gray-300">
            Don't have an account?{' '}
            <a href="/signup" className="text-blue-500">
              Sign up
            </a>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
