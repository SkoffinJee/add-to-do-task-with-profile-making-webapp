import React, { useState, useEffect } from 'react';

const Profile = () => {
  const [user, setUser] = useState({});
  const [updatedInfo, setUpdatedInfo] = useState({
    dateOfBirth: '',
    gender: '',
    address: '',
    religion: '',
  });
  const [mainInfo, setMainInfo] = useState({
    name: '',
    username: '',
    email: '',
    number: '',
  });
  const [newSkill, setNewSkill] = useState('');
  const [editPersonalMode, setEditPersonalMode] = useState(false);
  const [editMainMode, setEditMainMode] = useState(false);
  const [editSkillsMode, setEditSkillsMode] = useState(false);
  const [userSkills, setUserSkills] = useState([]);
  const [experience, setExperience] = useState({
    title: '',
    company: '',
    startDate: '',
    endDate: '',
    description: '',
  });
  const [editExperienceMode, setEditExperienceMode] = useState(false);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await fetch('http://localhost:3001/session-info', {
          method: 'GET',
          credentials: 'include',
        });

        if (response.ok) {
          const data = await response.json();
          setUser(data.user || {});
          setUserSkills(data.user?.skills || []);
          setMainInfo({
            name: data.user?.name || '',
            username: data.user?.username || '',
            email: data.user?.email || '',
            number: data.user?.number || '',
          });
        } else {
          console.error('Error fetching user information:', response.statusText);
        }
      } catch (error) {
        console.error('Error fetching user information:', error);
      }
    };

    fetchUserData();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdatedInfo({ ...updatedInfo, [name]: value });
  };

  const handleInputChangeExperience = (e) => {
    const { name, value } = e.target;
    setExperience({ ...experience, [name]: value });
  };

  const handleUpdateProfile = async () => {
    try {
      const response = await fetch('http://localhost:3001/update-personal-info', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updatedInfo),
        credentials: 'include',
      });

      if (response.ok) {
        const userResponse = await fetch('http://localhost:3001/session-info', {
          method: 'GET',
          credentials: 'include',
        });

        if (userResponse.ok) {
          const userData = await userResponse.json();
          setUser(userData.user || {});
          setEditPersonalMode(false);
          console.log('Profile updated successfully:', userData.user);
        } else {
          console.error('Error fetching updated user information:', userResponse.statusText);
        }
      } else {
        console.error('Error updating profile:', response.statusText);
      }
    } catch (error) {
      console.error('Error updating profile:', error);
    }
  };

  const handleAddSkill = async () => {
    try {
      const response = await fetch('http://localhost:3001/add-skill', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ skill: { title: newSkill } }),
        credentials: 'include',
      });

      if (response.ok) {
        const userData = await response.json();
        setUser(userData.user || {});
        setUserSkills(userData.user?.skills || []);
        setNewSkill('');
        console.log('Skill added successfully:', userData.user);
      } else {
        console.error('Error adding skill:', response.statusText);
      }
    } catch (error) {
      console.error('Error adding skill:', error);
    }
  };

  const handleDeleteSkill = async (skillId) => {
    try {
      const response = await fetch(`http://localhost:3001/delete-skill/${skillId}`, {
        method: 'DELETE',
        credentials: 'include',
      });

      if (response.ok) {
        const userData = await response.json();
        setUser(userData.user || {});
        setUserSkills(userData.user?.skills || []);
        console.log('Skill deleted successfully:', userData.user);
      } else {
        console.error('Error deleting skill:', response.statusText);
      }
    } catch (error) {
      console.error('Error deleting skill:', error);
    }
  };

  const handleAddExperience = async () => {
    try {
      const response = await fetch('http://localhost:3001/add-experience', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(experience),
        credentials: 'include',
      });

      if (response.ok) {
        const userData = await response.json();
        setUser(userData.user || {});
        setExperience({
          title: '',
          company: '',
          startDate: '',
          endDate: '',
          description: '',
        });
        console.log('Experience added successfully:', userData.user);
      } else {
        console.error('Error adding experience:', response.statusText);
      }
    } catch (error) {
      console.error('Error adding experience:', error);
    }
  };

  const handleDeleteExperience = async (experienceId) => {
    try {
      const response = await fetch(`http://localhost:3001/delete-experience/${experienceId}`, {
        method: 'DELETE',
        credentials: 'include',
      });
  
      if (response.ok) {
        const userData = await response.json();
        setUser(userData.user || {});
        console.log('Experience deleted successfully:', userData.user);
      } else {
        console.error('Error deleting experience:', response.statusText);
      }
    } catch (error) {
      console.error('Error deleting experience:', error);
    }
  };

  const handleSaveMainInfo = async () => {
    try {
      const response = await fetch('http://localhost:3001/update-main-info', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(mainInfo),
        credentials: 'include',
      });

      if (response.ok) {
        const userData = await response.json();
        setUser(userData.user || {});
        setEditMainMode(false);
        console.log('Main information updated successfully:', userData.user);
      } else {
        console.error('Error updating main information:', response.statusText);
      }
    } catch (error) {
      console.error('Error updating main information:', error);
    }
  };
  const handleEditMainInfoClick = () => {
    setMainInfo({
      name: user.name || '',
      username: user.username || '',
      email: user.email || '',
      number: user.number || '',
    });
    setEditMainMode(true);
  };
  

  const handleEditExperienceClick = () => {
    setEditExperienceMode(true);
  };

  const handleSaveEditExperience = () => {
    setEditExperienceMode(false);
  };

  const handleSavePersonalInfo = async () => {
    await handleUpdateProfile();
  };

  const handleEditPersonalInfoClick = () => {
    setUpdatedInfo({
      dateOfBirth: user.personalInformation?.dateOfBirth || '',
      gender: user.personalInformation?.gender || '',
      address: user.personalInformation?.address || '',
      religion: user.personalInformation?.religion || '',
    });
    setEditPersonalMode(true);
  };

  return (
    <div className="bg-gradient-to-r from-purple-900 to-blue-800 text-black">
        <div className="container max-w-3xl p-4 mx-auto" style={{ background: '#f0f0f0', borderRadius: '8px', boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)' }}>
          <h2 className="text-2xl font-bold mb-4">My Profile</h2>

                {/* Display User Main Information */}
                <div className="mb-8 ">
                  <h3 className="flex justify-between font-bold">
                    Main information
                    {editMainMode && (
                      <button className="border-2 border-purple-500 py-0 px-1  rounded text-purple-500 hover:bg-purple-500 hover:text-white" onClick={handleSaveMainInfo}>Save</button>
                    )}
                    {!editMainMode && (
                      <button className="border-2 border-purple-500 py-0 px-1  rounded text-purple-500 hover:bg-purple-500 hover:text-white" onClick={handleEditMainInfoClick}>
                      Edit
                    </button>
                    
                    )}
                  </h3>

                  {editMainMode ? (
                    <>
                      <div>
                        <label>Name:</label>
                        <input
                          type="text"
                          name="name"
                          value={mainInfo.name}
                          onChange={(e) => setMainInfo({ ...mainInfo, name: e.target.value })}
                        />
                      </div>
                      <div>
                        <label>Username:</label>
                        <input
                          type="text"
                          name="username"
                          value={mainInfo.username}
                          onChange={(e) => setMainInfo({ ...mainInfo, username: e.target.value })}
                        />
                      </div>
                      <div>
                        <label>Email:</label>
                        <input
                          type="text"
                          name="email"
                          value={mainInfo.email}
                          onChange={(e) => setMainInfo({ ...mainInfo, email: e.target.value })}
                        />
                      </div>
                      <div>
                        <label>number:</label>
                        <input
                          type="text"
                          name="number"
                          value={mainInfo.number}
                          onChange={(e) => setMainInfo({ ...mainInfo, number: e.target.value })}
                        />
                      </div>
                      <hr />
                    </>
                  ) : (
                    <>
                      {/* Display Main Information */}
                      <div>
                        <strong>Name:</strong> {user.name || 'N/A'}
                      </div>
                      <div>
                        <strong>Username:</strong> {user.username || 'N/A'}
                      </div>
                      <div>
                        <strong>Email:</strong> {user.email || 'N/A'}
                      </div>
                      <div>
                        <strong>number:</strong> {user.number || 'N/A'}
                      </div>
                      <hr />
                    </>
                  )}
                </div>



                {/* Display User Personal Information */}
                <div className="mb-8">
                  <div>
                    <h3 className="flex justify-between items-center font-bold">
                      Personal information
                      {editPersonalMode && (
                        <button className="border-2 border-purple-500 py-0 px-1 rounded text-purple-500 hover:bg-purple-500 hover:text-white" onClick={handleSavePersonalInfo}>Save</button>
                      )}
                      {!editPersonalMode && (
                        <button className="border-2 border-purple-500 py-0 px-1 rounded text-purple-500 hover:bg-purple-500 hover:text-white" onClick={handleEditPersonalInfoClick}>
                          Edit
                        </button>
                      )}
                    </h3>

                    {editPersonalMode ? (
                      <>
                        <div>
                          <label>Date of Birth:</label>
                          <input
                            type="date"
                            name="dateOfBirth"
                            value={updatedInfo.dateOfBirth}
                            onChange={handleInputChange}
                          />
                        </div>
                        <div>
                          <label>Gender:</label>
                          <select
                            name="gender"
                            value={updatedInfo.gender}
                            onChange={handleInputChange}
                          >
                            <option value="">Select Gender</option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                            <option value="others">Others</option>
                          </select>
                        </div>
                        <div>
                          <label>Address:</label>
                          <input
                            type="text"
                            name="address"
                            value={updatedInfo.address}
                            onChange={handleInputChange}
                          />
                        </div>
                        <div>
                          <label>Religion:</label>
                          <input
                            type="text"
                            name="religion"
                            value={updatedInfo.religion}
                            onChange={handleInputChange}
                          />
                        </div>
                      </>
                    ) : (
                      <>
                        {/* Display Personal Information */}
                        <div>
                          <strong>Date of Birth:</strong> {user.personalInformation?.dateOfBirth || 'N/A'}
                        </div>
                        <div>
                          <strong>Gender:</strong> {user.personalInformation?.gender || 'N/A'}
                        </div>
                        <div>
                          <strong>Address:</strong> {user.personalInformation?.address || 'N/A'}
                        </div>
                        <div>
                          <strong>Religion:</strong> {user.personalInformation?.religion || 'N/A'}
                        </div>
                        <hr />
                      </>
                    )}
                  </div>
                </div>




                {/* Display User Skills */}
    <div className="mb-8">
      <h3 className="flex justify-between items-center font-bold">
        Skills:
        {editSkillsMode && (
          <button className="border-2 border-blue-500 py-1 px-2 rounded text-blue-500 hover:bg-blue-500 hover:text-white" onClick={() => setEditSkillsMode(false)}>
            Save
          </button>
        )}
        {!editSkillsMode && (
          <button className="border-2 border-purple-500 py-1 px-2 rounded text-purple-500 hover:bg-purple-500 hover:text-white" onClick={() => setEditSkillsMode(true)}>
            Edit
          </button>
        )}
      </h3>

      {editSkillsMode && (
        <>
          <div className="mt-4">
            <label>Add Skill:</label>
            <input
              type="text"
              name="newSkill"
              value={newSkill}
              onChange={(e) => setNewSkill(e.target.value)}
            />
            <button className="border-2 border-blue-500 py-1 px-2 rounded text-blue-500 hover:bg-blue-500 hover:text-white" onClick={handleAddSkill}>
              Add Skill
            </button>
          </div>
        </>
      )}

      <div className="mt-4">
        <ul>
          {userSkills.map((skill, index) => (
            <li key={index} className="flex items-center">
              <span>{skill.title}</span>
              {editSkillsMode && (
                <button onClick={() => handleDeleteSkill(skill._id)} className="ml-2 text-red-500 border-2 border-red-500 rounded px-1 hover:text-red-700 hover:border-red-700">
                  Delete
                </button>
              )}
            </li>
          ))}
        </ul>
      </div>
      <hr/>
    </div>



                {/* Display User Experiences */}
    <div className="mb-8">
      <h3 className="flex justify-between items-center font-bold">
        Experiences:
        {editExperienceMode && (
          <button className="border-2 border-blue-500 py-1 px-2 rounded text-blue-500 hover:bg-blue-500 hover:text-white" onClick={handleSaveEditExperience}>
            Save
          </button>
        )}
        {!editExperienceMode && (
          <button className="border-2 border-purple-500 py-1 px-2 rounded text-purple-500 hover:bg-purple-500 hover:text-white" onClick={handleEditExperienceClick}>
            Edit
          </button>
          
        )}
      </h3>

      <div className="mt-4">
        {/* Display experiences */}
        {user.experience && user.experience.length > 0 ? (
          <ul>
            {user.experience.map((exp, index) => (
              <li key={index} className="flex items-center">
                <span>
                  <strong>Title:</strong> {exp.title}<br />
                  <strong>Company:</strong> {exp.company}<br />
                  <strong>Start Date:</strong> {exp.startDate}<br />
                  <strong>End Date:</strong> {exp.endDate}<br />
                  <strong>Description:</strong> {exp.description}<br />
                </span>
                {/* Delete Experience button */}
                {editExperienceMode && (
                  <button onClick={() => handleDeleteExperience(exp._id)} className="ml-2 text-red-500 border-2 border-red-500 rounded px-1 hover:text-red-700 hover:border-red-700">
                    Delete
                  </button>
                )}
              </li>
            ))}
          </ul>
        ) : (
          <p>No experiences to display.</p>
        )}

        {editExperienceMode && (
          <>
            <div className="mt-4">
              <label>Title:</label>
              <input
                type="text"
                name="title"
                value={experience.title}
                onChange={handleInputChangeExperience}
              />
            </div>
            <div className="mt-4">
              <label>Company:</label>
              <input
                type="text"
                name="company"
                value={experience.company}
                onChange={handleInputChangeExperience}
              />
            </div>
            <div className="mt-4">
              <label>Start Date:</label>
              <input
                type="date"
                name="startDate"
                value={experience.startDate}
                onChange={handleInputChangeExperience}
              />
            </div>
            <div className="mt-4">
              <label>End Date:</label>
              <input
                type="date"
                name="endDate"
                value={experience.endDate}
                onChange={handleInputChangeExperience}
              />
            </div>
            <div className="mt-4">
              <label>Description:</label>
              <textarea
                name="description"
                value={experience.description}
                onChange={handleInputChangeExperience}
              />
            </div>
            <button className="border-2 border-blue-500 py-1 px-2 rounded text-blue-500 hover:bg-blue-500 hover:text-white" onClick={handleAddExperience}>
              Add Experience
            </button>
          </>
        )}
      </div>
    </div>
    <hr />

        
        
        </div>
    </div>
  );
};

export default Profile; 