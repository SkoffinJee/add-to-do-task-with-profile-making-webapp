import React, { useState, useEffect } from 'react';

const Tasks = () => {
  const [tasks, setTasks] = useState([]);
  const [username, setUsername] = useState(null);
  const [newTask, setNewTask] = useState('');
  const [reloadFlag, setReloadFlag] = useState(false);

  useEffect(() => {
    const fetchUserInfo = async () => {
      try {
        const response = await fetch('http://localhost:3001/session-info', {
          method: 'GET',
          credentials: 'include',
        });

        if (response.ok) {
          const userData = await response.json();
          setUsername(userData.user.username);
        } else {
          console.error('Error fetching user data');
        }
      } catch (error) {
        console.error('Error:', error);
      }
    };

    const fetchTasks = async () => {
      try {
        const response = await fetch('http://localhost:3001/tasks', {
          method: 'GET',
          credentials: 'include',
        });

        if (response.ok) {
          const tasksData = await response.json();
          setTasks(tasksData.tasks);
        } else {
          console.error('Error fetching tasks');
        }
      } catch (error) {
        console.error('Error:', error);
      }
    };

    fetchUserInfo();
    fetchTasks();
  }, []);

  const handleAddTask = async () => {
    try {
      // Check if the newTask is not empty
      if (!newTask.trim()) {
        console.warn('Task title cannot be empty.');
        return;
      }

      const response = await fetch('http://localhost:3001/tasks', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          title: newTask,
          completion: false,
        }),
      });

      if (response.ok) {
        const newTaskData = await response.json();
        setTasks([...tasks, newTaskData.task]);
        setNewTask('');
      } else {
        console.error('Error adding task');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const handleToggleCompletion = async (taskId) => {
    try {
      const updatedCompletionStatus = !tasks.find((task) => task._id === taskId).completion;

      const response = await fetch(`http://localhost:3001/tasks/${taskId}`, {
        method: 'PATCH',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          completion: updatedCompletionStatus,
        }),
      });

      if (response.ok) {
        const updatedTasks = tasks.map((task) =>
          task._id === taskId ? { ...task, completion: updatedCompletionStatus } : task
        );
        setTasks(updatedTasks);
        console.log('Task completion status updated successfully.');
      } else {
        console.error('Error updating task completion status');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const handleDeleteTask = async (taskId) => {
    try {
      const response = await fetch(`http://localhost:3001/${taskId}`, {
        method: 'DELETE',
        credentials: 'include',
      });

      if (response.ok) {
        const updatedTasks = tasks.filter((task) => task._id !== taskId);
        setTasks(updatedTasks);
        console.log('Task deleted successfully.');
      } else {
        console.error('Error deleting task');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <div className="bg-gradient-to-r from-purple-900 to-blue-800">
    <div className="container mx-auto flex flex-col items-center min-h-screen">
      {username ? (
        <h2 className="text-white text-3xl font-bold mb-4">{`${username}'s Tasks`}</h2>
      ) : (
        <p>Loading...</p>
      )}
      <div className="mb-4 w-full md:w-96">
        <input
          type="text"
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
          className="w-full border border-gray-300 px-2 py-1 rounded-full focus:outline-none focus:ring focus:border-blue-300"
        />
        <button
          onClick={handleAddTask}
          className="mt-2 w-full px-4 py-2 bg-gradient-to-r from-yellow-500 to-orange-500 text-white rounded-full hover:from-yellow-600 hover:to-orange-600"
        >
          Add Task
        </button>
      </div>
      <div className="border border-gray-300 p-4 w-full md:w-3/5 text-left bg-gray-300 overflow-y-auto">
        <h3 className="text-xl font-bold mb-2">Tasks</h3>
        <ul className="list-disc w-full">
          {tasks.map((task) => (
            <li
              key={task._id}
              className="flex flex-col md:flex-row items-center justify-between border-b border-gray-300 py-2"
            >
              <span
                className={`text-xl flex-grow ${task.completion ? 'line-through' : ''}`}
              >
                {task.title}
              </span>
              <div className="flex items-center space-x-2 mt-2 md:mt-0 md:ml-auto">
                <button
                  onClick={() => handleToggleCompletion(task._id)}
                  className={`px-2 py-1 mr-3 rounded-full ${
                    task.completion
                      ? 'bg-gradient-to-r from-gray-400 to-gray-800 text-gray-800'
                      : 'bg-gradient-to-r from-green-500 to-green-600 text-white hover:from-green-600 hover:to-green-700'
                  }`}
                >
                  {task.completion ? '✔️' : 'Complete'}
                </button>
                <button
                  onClick={() => handleDeleteTask(task._id)}
                  className="ml-3 px-2 py-1 bg-gradient-to-r from-red-500 to-red-600 text-white rounded-full hover:from-red-600 hover:to-red-700"
                >
                  ❌
                </button>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
    </div>
  );
};

export default Tasks;
