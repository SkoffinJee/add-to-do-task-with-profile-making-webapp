import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const TextTransition = ({ text }) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);

    const timeoutId = setTimeout(() => {
      setIsVisible(false);
    }, 2000); // Adjust the time as needed, should be the same as the transition duration

    return () => clearTimeout(timeoutId);
  }, [text]);

  return (
    <span className={`text-xl transition-opacity duration-500 ease-in-out ${isVisible ? 'opacity-100' : 'opacity-0'}`}>
      {text}
    </span>
  );
};

const Home = () => {
  const [text, setText] = useState('Editors');
  const alternativeTexts = ['Web developers', 'Gamers', 'Designers'];
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const intervalId = setInterval(() => {
      const randomIndex = Math.floor(Math.random() * alternativeTexts.length);
      setText(alternativeTexts[randomIndex]);
    }, 3000); // Adjust the time as needed, should be greater than the transition duration

    // Cleanup interval on component unmount
    return () => clearInterval(intervalId);
  }, [alternativeTexts]);

  useEffect(() => {
    const checkAuthenticationStatus = async () => {
      try {
        const response = await fetch('http://localhost:3001/session-info', {
          method: 'GET',
          credentials: 'include',
        });

        if (response.ok) {
          const userData = await response.json();
          setIsLoggedIn(!!userData.user);

          if (userData.user) {
            setUsername(userData.user.name);
          }
        }
      } catch (error) {
        console.error('Error checking authentication status:', error);
      }
    };

    checkAuthenticationStatus();
  }, []);

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gradient-to-r from-purple-900 to-blue-800 text-white">
      <div className="max-w-screen-md mx-auto p-6">
        {isLoggedIn ? (
          <h2 className="text-4xl font-bold mb-4 transition-opacity duration-500 ease-in-out opacity-100 hover:opacity-100">
            Welcome, {username}!
          </h2>
        ) : (
          <>
            <h2 className="text-4xl font-bold mb-4 transition-opacity duration-500 ease-in-out opacity-100 hover:opacity-100">
              Welcome to our Website
            </h2>
            <TextTransition text={`We are ${text}`} />
          </>
        )}
      </div>
    </div>
  );
};

export default Home;
