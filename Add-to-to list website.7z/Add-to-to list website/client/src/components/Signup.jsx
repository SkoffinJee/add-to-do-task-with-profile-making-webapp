import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Signup = () => {
  const [user, setUser] = useState({
    name: '',
    username: '',
    email: '',
    number: '',
    password: '',
    cpassword: '',
  });
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleSignup = async () => {
    try {
      // Send the form data to the backend
      const response = await fetch('http://localhost:3001/signup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(user),
      });

      // Handle the response from the backend
      if (response.ok) {
        console.log('Form submitted successfully');
        navigate('/login');
      } else {
        console.error('Error submitting the form');
        // Handle the error, show a message, etc.
      }
    } catch (error) {
      console.error('Error:', error);
      // Handle the error, show a message, etc.
    }
  };

  return (
    <div className="bg-cover bg-center h-screen" style={{ backgroundImage: 'url("./media/signupbg.jpg")' }}>
      <div className="flex items-center justify-center h-screen">
        <div className="w-96 mx-auto p-4 bg-gray-700 shadow-md rounded-md">
          <h2 className="text-3xl font-semibold mb-4 text-center text-blue-500">Signup</h2>
          <form>
            <div className="mb-4">
              <label htmlFor="name" className="block text-sm font-medium text-gray-300">
                Name:
              </label>
              <input
                type="text"
                name="name"
                value={user.name}
                onChange={handleChange}
                className="mt-1 p-2 border border-purple-800 w-full rounded-full bg-gray-800 text-white focus:outline-none focus:ring focus:border-purple-600"
              />
            </div>
            <div className="mb-4">
              <label htmlFor="username" className="block text-sm font-medium text-gray-300">
                Username:
              </label>
              <input
                type="text"
                name="username"
                value={user.username}
                onChange={handleChange}
                className="mt-1 p-2 border border-purple-800 w-full rounded-full bg-gray-800 text-white focus:outline-none focus:ring focus:border-purple-600"
              />
            </div>
            <div className="mb-4">
              <label htmlFor="email" className="block text-sm font-medium text-gray-300">
                Email:
              </label>
              <input
                type="email"
                name="email"
                value={user.email}
                onChange={handleChange}
                className="mt-1 p-2 border border-purple-800 w-full rounded-full bg-gray-800 text-white focus:outline-none focus:ring focus:border-purple-600"
              />
            </div>
            <div className="mb-4">
              <label htmlFor="number" className="block text-sm font-medium text-gray-300">
                Number:
              </label>
              <input
                type="text"
                name="number"
                value={user.number}
                onChange={handleChange}
                className="mt-1 p-2 border border-purple-800 w-full rounded-full bg-gray-800 text-white focus:outline-none focus:ring focus:border-purple-600"
              />
            </div>
            <div className="mb-4">
              <label htmlFor="password" className="block text-sm font-medium text-gray-300">
                Password:
              </label>
              <input
                type="password"
                name="password"
                value={user.password}
                onChange={handleChange}
                className="mt-1 p-2 border border-purple-800 w-full rounded-full bg-gray-800 text-white focus:outline-none focus:ring focus:border-purple-600"
              />
            </div>
            <div className="mb-6">
              <label htmlFor="cpassword" className="block text-sm font-medium text-gray-300">
                Confirm Password:
              </label>
              <input
                type="password"
                name="cpassword"
                value={user.cpassword}
                onChange={handleChange}
                className="mt-1 p-2 border border-purple-800 w-full rounded-full bg-gray-800 text-white focus:outline-none focus:ring focus:border-purple-600"
              />
            </div>
            <button
              type="button"
              onClick={handleSignup}
              className="w-full bg-purple-800 text-white p-3 rounded-full hover:bg-purple-900 focus:outline-none focus:ring focus:border-purple-900"
            >
              Signup
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Signup;
