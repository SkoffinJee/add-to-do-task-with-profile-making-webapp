const express = require('express');
const bcrypt = require('bcrypt');
const User = require('../models/users');
const session = require('express-session');
const authenticateUser = require('../authmiddleware/authMiddleware');
const cookieParser = require('cookie-parser');
const router = express.Router();

router.use(cookieParser());

// Add this middleware at the beginning of your server code
router.use((req, res, next) => {
  console.log(`Received ${req.method} request at ${req.url}`);
  next();
});


// Welcome route
router.get('/', (req, res) => {
  res.send('Welcome to the homepage from the server');
  // console.log('Welcome to the homepage from the server');
});

// User registration route
router.post('/signup', async (req, res) => {
  const { name, username, email, number, password, cpassword } = req.body;

  try {
    console.log('signup route running')
    const userExist = await User.findOne({ $or: [{ username }, { email }, { number }] });

    if (userExist) {
      return res.status(400).json({ message: 'Username, email, or number already exists' });
    }

    const user = new User({ name, username, email, number, password, cpassword });
    await user.save();

    res.status(200).json({ message: 'Registered successfully' });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});

// User login route
router.post('/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    const user = await User.findOne({ username });

    if (!user) {
      console.log('User not found');
      return res.status(404).json({ message: 'User not found' });
    }

    const exist = await bcrypt.compare(password, user.password);
    if (!exist) {
      console.log('Invalid username or password');
      return res.status(401).json({ message: 'Invalid username or password' });
    }

    const token = await user.generateAuthToken();
    console.log('Login successfully');

    // Store the entire user object in the session, including additional info
    req.session.user = user;

    // Set the 'token' cookie with the generated token
    res.cookie('userlogin', token, {
      expires: new Date(Date.now() + 25892000000),
      httpOnly: true,
    });

    res.status(200).json({ message: 'Login successful', username: user.username });
  } catch (err) {
    console.error('Error during login:', err);
    res.status(500).json({ err: 'Server error' });
  }
});


// User session information route
// Add this route to your server-side code

// User session information route
router.get('/session-info', authenticateUser, (req, res) => {
  // Ensure that `req.user` contains the necessary user information
  if (req.user) {
    // console.log('User Session:', req.user);
    res.json({ user: req.user });
  } 
  else {
    res.status(401).json({ message: 'Unauthorized from session-info route' });
  }
});


// User logout route
router.post('/logout', (req, res) => {
  try {
    req.session.destroy((err) => {
      if (err) {
        console.error('Logout error:', err);
        res.status(500).json({ message: 'Internal Server Error' });
      } else {
        res.clearCookie('userlogin');
        res.status(200).json({ message: 'Logout successful' });
      }
    });
  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});

// Get tasks route
router.get('/tasks', authenticateUser, async (req, res) => {
  try {
    const user = await User.findById(req.session.user._id);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.status(200).json({ tasks: user.tasklist });
  } catch (error) {
    console.error('Error fetching tasks:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});

// Add new task route
router.post('/tasks', authenticateUser, async (req, res) => {
  try {
    const { title, completion } = req.body;
    const user = await User.findById(req.user._id);

    user.tasklist.push({ title, completion });
    await user.save();

    res.status(201).json({ message: 'Task added successfully', task: user.tasklist[user.tasklist.length - 1] });
  } catch (error) {
    console.error('Error adding task:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});

// Update task completion status route
router.patch('/tasks/:taskId', authenticateUser, async (req, res) => {
  const userId = req.session.user._id;
  const taskId = req.params.taskId;

  try {
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const task = user.tasklist.id(taskId);

    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }

    task.completion = !task.completion;
    await user.save();

    res.status(200).json({ message: 'Task completion status updated', task });
  } catch (error) {
    console.error('Error updating task completion status:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});

// Delete task route
router.delete('/:taskId', authenticateUser, async (req, res) => {
  const userId = req.session.user._id;
  const taskId = req.params.taskId;

  try {
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const taskIndex = user.tasklist.findIndex(task => task._id.toString() === taskId);

    if (taskIndex === -1) {
      return res.status(404).json({ message: 'Task not found' });
    }

    user.tasklist.splice(taskIndex, 1);
    await user.save();

    res.status(200).json({ message: 'Task deleted successfully' });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});



// // Route to handle updating additional information in the profile
// router.put('/profile', authenticateUser, async (req, res) => {
//   const userId = req.user._id; // Assuming you have a middleware that sets req.user with the authenticated user

//   try {
//     // Fetch the user from the database
//     const user = await User.findById(userId);

//     if (!user) {
//       return res.status(404).json({ message: 'User not found' });
//     }

//     // Update additional information based on the request
//     if (req.body.personalInfo) {
//       user.additionalInfo.personalInfo = { ...user.additionalInfo.personalInfo, ...req.body.personalInfo };
//     }

//     if (req.body.socialNetworks) {
//       user.additionalInfo.socialNetworks = req.body.socialNetworks;
//     }

//     if (req.body.skills) {
//       user.additionalInfo.skills = req.body.skills;
//     }

//     // Save the updated user to the database
//     await user.save();

//     // Respond with the updated user object
//     res.status(200).json({ message: 'Additional information updated successfully', user });
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ error: 'Internal server error' });
//   }
// });


// router.put('/update-profile', async (req, res) => {
//   const userId = req.session.user._id;

//   try {
//     const user = await User.findById(userId);

//     if (!user) {
//       return res.status(404).json({ message: 'User not found' });
//     }

//     // Update user information
//     user.name = req.body.name || user.name;
//     user.email = req.body.email || user.email;
//     user.number = req.body.number || user.number;

//     // Save the updated user
//     await user.save();

//     // Send the updated user data back to the client
//     res.status(200).json({ user });
//   } catch (error) {
//     console.error('Error updating user profile:', error);
//     res.status(500).json({ message: 'Internal Server Error' });
//   }
// });




// router.delete('/delete-info', async (req, res) => {
//   const userId = req.session.user._id;
//   const infoTypesToDelete = req.body.infoTypes; // You can pass an array of information types to delete in the request body

//   try {
//     const user = await User.findById(userId);

//     if (!user) {
//       return res.status(404).json({ message: 'User not found' });
//     }

//     // Check if the specified information types exist
//     if (!user.additionalInfo) {
//       return res.status(404).json({ message: 'User profile does not contain additional information' });
//     }

//     // Delete the specified information types
//     infoTypesToDelete.forEach(infoType => {
//       if (user.additionalInfo[infoType]) {
//         delete user.additionalInfo[infoType];
//       }
//     });

//     // Save the updated user
//     await user.save();

//     // Send the updated user data back to the client
//     res.status(200).json({ user });
//   } catch (error) {
//     console.error('Error deleting user information:', error);
//     res.status(500).json({ message: 'Internal Server Error' });
//   }
// });


// Route to handle updating personal information in the profile
router.put('/update-personal-info', authenticateUser, async (req, res) => {
  const userId = req.session.user._id;

  try {
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Update personal information based on the request body
    user.personalInformation.dateOfBirth = req.body.dateOfBirth || user.personalInformation.dateOfBirth;
    user.personalInformation.gender = req.body.gender || user.personalInformation.gender;
    user.personalInformation.address = req.body.address || user.personalInformation.address;
    user.personalInformation.religion = req.body.religion || user.personalInformation.religion;

    // Save the updated user to the database
    await user.save();

    // Respond with the updated user object
    res.status(200).json({ message: 'Personal information updated successfully', user });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal server error' });
  }
});


// Add skill route
// router.post('/add-skill', authenticateUser, async (req, res) => {
//   const userId = req.session.user._id;

//   try {
//     const user = await User.findById(userId);

//     if (!user) {
//       return res.status(404).json({ message: 'User not found' });
//     }

//     // Extract the skill from the request body
//     const { skill } = req.body;

//     // Check if the skill already exists in the user's skills
//     if (user.skills.includes(skill)) {
//       return res.status(400).json({ message: 'Skill already exists' });
//     }

//     // Add the skill to the user's skills array
//     user.skills.push(skill);

//     // Save the updated user to the database
//     await user.save();

//     // Respond with the updated user object
//     res.status(200).json({ message: 'Skill added successfully', user });
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ error: 'Internal server error' });
//   }
// });


// Route to add a skill for the logged-in user
router.post('/add-skill', authenticateUser, async (req, res) => {
  try {
    const { skill } = req.body;
    const userId = req.user._id; // Assuming you have implemented authentication middleware

    // Find the user by ID
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Add the skill to the user's skills array
    user.skills.push(skill);

    // Save the updated user
    await user.save();

    res.status(200).json({ user });
  } catch (error) {
    console.error('Error adding skill:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});


// Route to add a skill
router.post('/add-skill', authenticateUser, async (req, res) => {
  try {
    console.log('Request Body:', req.body);
    // Get the skill from the request body
    const { skill } = req.body;
    console.log('Skill to Add:', skill);

    // Find the user by ID
    const user = await User.findById(req.user._id);

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Add the skill to the user's skills array
    user.skills.push({ title: skill.title });

    // Save the user with the new skill
    await user.save();

    // Respond with the updated user
    res.status(200).json({ user });
  } catch (error) {
    console.error('Error adding skill:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});


// Route to delete a skill
router.delete('/delete-skill/:skillId', authenticateUser, async (req, res) => {
  try {
    // Find the user by ID from the authentication middleware
    const user = req.user;

    // Get the skillId from the request parameters
    const skillId = req.params.skillId;

    // Remove the skill from the user's skills array
    user.skills = user.skills.filter(skill => skill._id.toString() !== skillId);

    // Save the updated user
    await user.save();

    res.status(200).send({ user });
  } catch (error) {
    console.error('Error deleting skill:', error);
    res.status(500).send({ error: 'Internal Server Error' });
  }
});






// Route to add experience for the logged-in user
router.post('/add-experience', authenticateUser, async (req, res) => {
  try {
    // Get user from the authentication middleware
    const user = req.user;

    // Extract experience details from the request body
    const { title, company, startDate, endDate, description } = req.body;

    // Initialize the experience array if it's not present
    user.experience = user.experience || [];

    // Create a new experience object
    const newExperience = {
      title,
      company,
      startDate,
      endDate,
      description,
    };

    // Add the experience to the user's experience array
    user.experience.push(newExperience);

    // Save the updated user
    await user.save();
    console.log('the experience has been added')

    res.status(201).send({ user });
  } catch (error) {
    console.error('Error adding experience:', error);
    res.status(500).send({ error: 'Internal Server Error' });
  }
});



// Route to delete an experience for the logged-in user
router.delete('/delete-experience/:experienceId', authenticateUser, async (req, res) => {
  try {
    // Get user from the authentication middleware
    const user = req.user;

    // Get the experienceId from the request parameters
    const experienceId = req.params.experienceId;

    // Find the index of the experience in the user's experience array
    const experienceIndex = user.experience.findIndex(exp => exp._id.toString() === experienceId);

    // Check if the experience exists
    if (experienceIndex === -1) {
      return res.status(404).json({ message: 'Experience not found' });
    }

    // Remove the experience from the user's experience array
    user.experience.splice(experienceIndex, 1);

    // Save the updated user
    await user.save();

    res.status(200).send({ user });
  } catch (error) {
    console.error('Error deleting experience:', error);
    res.status(500).send({ error: 'Internal Server Error' });
  }
});



// Update main information route
router.put('/update-main-info',authenticateUser, async (req, res) => {
  const { name, email, number } = req.body;

  try {
    // Assuming you have a user ID available in the request, you can get it from your authentication middleware
    const userId = req.user._id; // Replace this with your actual method of getting the user ID

    // Update user in the database
    const updatedUser = await User.findByIdAndUpdate(
      userId,
      { name, email, number },
      { new: true } // Return the updated user
    );

    if (updatedUser) {
      res.json({ success: true, user: updatedUser });
    } else {
      res.status(404).json({ success: false, error: 'User not found' });
    }
  } catch (error) {
    console.error('Error updating main information:', error);
    res.status(500).json({ success: false, error: 'Internal Server Error' });
  }
});




module.exports = router;