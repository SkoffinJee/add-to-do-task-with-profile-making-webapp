const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const taskSchema = new mongoose.Schema({
  title: {type: String,required: true},
  completion: {type: Boolean,default: false},
  user: {type: mongoose.Schema.Types.ObjectId,ref: 'users'}
});

const skillsSchema = new mongoose.Schema({
  title: {type: String,required: false},
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'users' },
});
const expSchema = new mongoose.Schema({
    title: { type: String },
    company: { type: String },
    startDate: { type: String },
    endDate: { type: String },
    description: { type: String },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'users' },
});
  
const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  username: { type: String, required: true, unique: true },
  email: { type: String, required: true, unique: true },
  number: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  cpassword: { type: String, required: true },
  personalInformation: {
    dateOfBirth: { type: String },
    gender: { type: String },
    address: { type: String },
    religion: { type: String },
  },
  skills: [skillsSchema],
  experience: [expSchema],
  tasklist: [taskSchema],
  tokens: [{ token: { type: String, required: true } }],
});

userSchema.pre('save', async function (next) {
  if (this.isModified('password')) {
    this.password = await bcrypt.hash(this.password, 12);
    this.cpassword = await bcrypt.hash(this.cpassword, 12);
  }
  return next();
});

userSchema.methods.generateAuthToken = async function () {
  try {
    const secretKey = process.env.secret_Key; // Replace with your actual secret key
    const token = jwt.sign({ _id: this._id }, secretKey);

    // Check if there's an existing token, and update it
    const existingTokenIndex = this.tokens.findIndex((t) => t.token);
    if (existingTokenIndex !== -1) {
      this.tokens[existingTokenIndex].token = token;
    } else {
      // If no existing token, add a new one
      this.tokens.push({ token });
    }

    await this.save();
    return token;
  } catch (err) {
    console.log(err);
  }
};

const users = mongoose.model('users', userSchema);
module.exports = users;
