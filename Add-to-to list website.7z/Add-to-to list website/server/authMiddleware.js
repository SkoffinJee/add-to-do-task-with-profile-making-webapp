const User = require('../models/users');

const authenticateUser = async (req, res, next) => {
  try {
    // Check if the user is logged in
    if (req.session.user && req.session.user._id && req.session.user.username) {
      // Retrieve the user from the database based on the session information
      const user = await User.findOne({
        _id: req.session.user._id,
        username: req.session.user.username,
      });

      // Check if the user exists in the database
      if (user) {
        // User is authenticated, attach the user object to the request for further use
        req.user = user;
        next();
      } else {
        // User is not authenticated, send an unauthorized response
        res.status(401).json({ message: 'Unauthorized authenticate middlware' });
      }
    } else {
      // User is not authenticated, send an unauthorized response
      res.status(401).json({ message: 'Unauthorized from authenticate middleware' });
    }
  } catch (error) {
    console.error('Authentication error:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};

module.exports = authenticateUser;
    