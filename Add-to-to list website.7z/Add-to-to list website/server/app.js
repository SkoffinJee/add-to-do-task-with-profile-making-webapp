const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const session = require('express-session');
const cors = require('cors');
const User = require('./models/users');

// Load environment variables
dotenv.config({ path: './config.env' });

// Create Express app
const app = express();

// Set up CORS options
const corsOptions = {
  origin: 'http://localhost:3000',
  methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
  credentials: true,
  optionsSuccessStatus: 204,
};

// Use session middleware
app.use(
  session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: true,
    cookie: {
      secure: false,
      maxAge: 2592000000,
    },
  })
);

// Use CORS middleware
app.use(cors(corsOptions));

// Use JSON middleware
app.use(express.json());

// Connect to MongoDB
require('./db/conn');

// Use the authentication router
app.use(require('./router/auth'));

// Define the port
const port = process.env.PORT || 3001;




if(process.env.NODE_ENV=="production"){
  app.use(express.static('client/dist'));
}

// Start the server
app.listen(port, () => {
  console.log(`The server is listening on port ${port}`);
});
